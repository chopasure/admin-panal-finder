# admin_penal
#How to Use 
#require python 2.7 on your ...anything
#command "chmod +x admin_panel_finder.py"
#python2 admin_panel_finder.py
now enter your website:

||warning|| This is Only for education purpose only i am not responsiable for any bad activity.
